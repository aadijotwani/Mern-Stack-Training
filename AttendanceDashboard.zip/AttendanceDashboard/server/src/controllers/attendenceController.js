export const markAttendence = async (req, res, next) => {
  try {
    // Logic to mark attendance
  } catch (error) {
    next(error);
  }
};

export const viewAttendence = async (req, res, next) => {
  try {
    // Logic to view attendance
  } catch (error) {
    next(error);
  }
};
